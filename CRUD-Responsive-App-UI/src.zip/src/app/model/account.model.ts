export class Account {
  Username: string;
  Password: string;
}
