export interface IUserElement {
  Id: string;
  FirstName: string;
  LastName: string;
  DateOfBirth: string;
  Action: Array<string>;
}
