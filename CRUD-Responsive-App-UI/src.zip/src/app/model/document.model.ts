export class DocumentModel {
  documentId: string;
  documentName: string;
  documentType: string;
  documentSize: number;
  documentData: string;
}
